#!/bin/bash
for file in $(ls $1*);
do
    mv $file ${file//$1/$2}
done
