for file in $(ls *.dot);
do
    dot -Tpdf $file >$(basename $file .dot).pdf
done
