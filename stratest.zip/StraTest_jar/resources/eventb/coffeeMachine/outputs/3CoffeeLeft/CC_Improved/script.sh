#!/bin/bash

for file in $(ls EUA*);
do
    mv $file ${file//EUA/PSI}
done

for file in $(ls UUA*);
do
    mv $file ${file//UUA/CC_Improved}
done
ls
