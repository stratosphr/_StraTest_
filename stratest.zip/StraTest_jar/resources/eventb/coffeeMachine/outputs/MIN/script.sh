#!/bin/bash

for file in $(ls UUA*);
do
    mv $file ${file//UUA/MIN}
    ls
done
