mkdir 3MTS
for file in $(ls 3MTS*)
do
    mv $file 3MTS
done

cd 3MTS
for file in $(ls *.dot)
do
    dot -Tpdf $file >$(replace -a $file ".dot" ".pdf")
done
