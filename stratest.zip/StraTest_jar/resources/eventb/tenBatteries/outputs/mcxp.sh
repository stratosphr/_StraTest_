for file in $(ls EUA*)
do
    mv $file $(replace $file "EUA" "MCXP")
done
for file in $(ls UUA*)
do
    mv $file $(replace $file "UUA" "REL_MCXP")
done
mkdir -p MCXP
mkdir -p REL_MCXP
mv MCXP* MCXP
mv REL_MCXP* REL_MCXP

cd MCXP
for file in $(ls *.dot)
do
    dot -Tpdf $file >$(replace -a $file ".dot" ".pdf")
done

cd ..

cd REL_MCXP
for file in $(ls *.dot)
do
    dot -Tpdf $file >$(replace -a $file ".dot" ".pdf")
done
