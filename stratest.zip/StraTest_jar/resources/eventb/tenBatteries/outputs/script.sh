for file in $(ls EUA*)
do
    mv $file $(replace $file "EUA" "CXP")
done
for file in $(ls UUA*)
do
    mv $file $(replace $file "UUA" "REL_CXP")
done
mkdir -p CXP
mkdir -p REL_CXP
mv CXP* CXP
mv REL_CXP* REL_CXP
