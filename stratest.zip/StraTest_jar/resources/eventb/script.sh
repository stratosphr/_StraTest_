for file in $(ls EUA*)
do
    mkdir CXP
    mv $file CXP_REL/$(replace $file "EUA" "CXP")
done
for file in $(ls UUA*)
do
    mkdir CXP_REL
    mv $file CXP_REL/$(replace $file "UUA" "CXP_REL")
done
